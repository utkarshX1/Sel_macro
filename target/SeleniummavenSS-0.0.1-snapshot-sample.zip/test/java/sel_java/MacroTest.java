package sel_java;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class MacroTest {
  
  

	  
public static void main(String[] args) {
	  System.out.println("Test passed");
	  
//	  String filepath="C:\\Users\\Kartik\\Desktop\\SampleData.xlsx";
//	  FileInputStream fstream= new FileInputStream(filepath);
//	  XSSFWorkbook wbook =new XSSFWorkbook(fstream);
//      XSSFSheet sheet= wbook.getSheet("SalesOrders");
//	  
//	  for(int i=0;i<sheet.getPhysicalNumberOfRows();i++) {		  XSSFRow row=sheet.getRow(i);
//		  if(row.getCell(3).getStringCellValue().equals("Pencil")) {
//		  System.out.println(i);
//			  row.getCell(3).setCellValue("Eraser");
//		  }
//		  else {
//			  continue;
//		  }
//	  }
//	  FileOutputStream fout=new FileOutputStream(filepath);
//	  wbook.write(fout);
//  wbook.close();
  
  }}
    
  

